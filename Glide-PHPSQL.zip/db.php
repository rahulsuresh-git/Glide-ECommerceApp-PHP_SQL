<?php
$conn = mysqli_connect("localhost", "root", "", "glide") or die ("Failed to connect");
?>